# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.9)
# Database: wt
# Generation Time: 2013-12-02 22:08:45 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table wt_comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_comments`;

CREATE TABLE `wt_comments` (
  `komentar_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `datum_pridania` datetime NOT NULL,
  `hodnotenie` tinyint(3) unsigned DEFAULT NULL,
  `komentar` text,
  `film_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`komentar_id`),
  KEY `autor_id` (`autor_id`),
  KEY `film_id` (`film_id`),
  CONSTRAINT `wt_comments_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `wt_users` (`pouzivatel_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wt_comments_ibfk_2` FOREIGN KEY (`film_id`) REFERENCES `wt_films` (`film_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table wt_countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_countries`;

CREATE TABLE `wt_countries` (
  `krajina_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `datum_pridania` datetime NOT NULL,
  `nazov` tinytext NOT NULL,
  `schvaleny` enum('0','1') NOT NULL,
  PRIMARY KEY (`krajina_id`),
  KEY `autor_id` (`autor_id`),
  CONSTRAINT `wt_countries_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `wt_users` (`pouzivatel_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table wt_film_country
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_film_country`;

CREATE TABLE `wt_film_country` (
  `film_id` int(10) unsigned NOT NULL,
  `krajina_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`film_id`,`krajina_id`),
  KEY `krajina_id` (`krajina_id`),
  KEY `film_id` (`film_id`),
  CONSTRAINT `wt_film_country_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `wt_films` (`film_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wt_film_country_ibfk_2` FOREIGN KEY (`krajina_id`) REFERENCES `wt_countries` (`krajina_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table wt_film_genre
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_film_genre`;

CREATE TABLE `wt_film_genre` (
  `film_id` int(10) unsigned NOT NULL,
  `zaner_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`film_id`,`zaner_id`),
  KEY `zaner_id` (`zaner_id`),
  KEY `film_id` (`film_id`),
  CONSTRAINT `wt_film_genre_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `wt_films` (`film_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wt_film_genre_ibfk_2` FOREIGN KEY (`zaner_id`) REFERENCES `wt_genres` (`zaner_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table wt_film_person
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_film_person`;

CREATE TABLE `wt_film_person` (
  `film_id` int(10) unsigned NOT NULL,
  `osobnost_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`film_id`,`osobnost_id`),
  KEY `osobnost_id` (`osobnost_id`),
  KEY `film_id` (`film_id`),
  CONSTRAINT `wt_film_person_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `wt_films` (`film_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wt_film_person_ibfk_2` FOREIGN KEY (`osobnost_id`) REFERENCES `wt_people` (`osobnost_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `wt_film_person` WRITE;
/*!40000 ALTER TABLE `wt_film_person` DISABLE KEYS */;

INSERT INTO `wt_film_person` (`film_id`, `osobnost_id`)
VALUES
	(1,1),
	(1,2),
	(1,3),
	(1,4),
	(1,5),
	(1,6),
	(1,7);

/*!40000 ALTER TABLE `wt_film_person` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wt_films
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_films`;

CREATE TABLE `wt_films` (
  `film_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `datum_pridania` datetime NOT NULL,
  `typ` enum('film','seriál') NOT NULL DEFAULT 'film',
  `nazov` tinytext NOT NULL,
  `originalny_nazov` tinytext,
  `fotografia` tinytext,
  `popis` text NOT NULL,
  `rok_vydania` smallint(5) unsigned DEFAULT NULL,
  `minutaz` smallint(5) unsigned DEFAULT NULL,
  `schvaleny` enum('0','1') NOT NULL DEFAULT '0',
  `pocet_casti` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`film_id`),
  KEY `autor_id` (`autor_id`),
  CONSTRAINT `wt_films_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `wt_users` (`pouzivatel_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `wt_films` WRITE;
/*!40000 ALTER TABLE `wt_films` DISABLE KEYS */;

INSERT INTO `wt_films` (`film_id`, `autor_id`, `datum_pridania`, `typ`, `nazov`, `originalny_nazov`, `fotografia`, `popis`, `rok_vydania`, `minutaz`, `schvaleny`, `pocet_casti`)
VALUES
	(1,1,'2013-12-01 09:38:55','film','Tajný život Waltera Mittyho','Secret Life of Walter Mitty, The','01_small.png','Walter Mitty (Ben Stiller), nesmělý a věčně snící fotoeditor časopisu Life, se ve svém jednotvárném životě jen těžko potkává s realitou, a proto raději žije ve svém vysněném světě. V něm se mění na dokonalého romantického hrdinu bojujícího za lepší, spravedlivější svět. Trestá padouchy, zachraňuje pejsky z hořících domů a ochraňuje bezbranné ženy. A také se ve svých snech stává cílem obdivných pohledů kolegyně Cheryl (Kristen Wiig), kterou bez jejího vědomí do svých snových toulek často angažuje. Ale i ve svém reálném životě se jednoho dne Walter musí rozhodnout k zásadnímu kroku do neznáma a opustit bezpečný přístav archivu plného negativů a fotografií, kde jsou jeho největším nepřítelem jen pomalu padající prach a ústrky šéfa (Adam Scott). Aby zabránil svému vyhazovu, musí najít ztracený negativ fotografie, která má být na titulní stránce časopisu. Kvůli tomu musí najít slavného fotografa Seana O\'Connella (Sean Penn). To ale neznamená zavolat si taxíka a zajet o pár bloků vedle. Představuje to dobrodružnou cestu okolo světa, putování divočinou a nejzapadlejšími kouty naší planety, protože nepolapitelný fotograf-dobrodruh je hvězdou fotožurnalistiky proslulou neúnavným odhodláním hnát se za příběhem bez ohledu na to, kam až jej zavede. A tak se Walter musí vydat po jeho stopách.',2013,114,'1',NULL),
	(2,1,'2013-12-02 22:38:14','film','Hobit: Smaugova pustatina','Hobbit: The Desolation Of Smaug','hobbit_small.jpg','Hobit: Šmakova dračí poušť líčí další dobrodružství hobita Bilbo Pytlíka na jeho společné pouti s čarodějem Gandalfem a třinácti trpaslíky vedenými Thorinem Pavézou. Vydali se na výpravnou cestu, jejímž cílem je získat zpět Osamělou horu a ztracené království trpaslíků Erebor. Poté, co přežili začátek své neočekávané cesty, pokračuje tato společnost směrem na Východ a cestou potkává kožoměnce Medděda a v lese Mirkwood plném nástrah se střetává s houfem obřích Pavouků. Když se jim podaří uniknout ze zajetí nebezpečných lesních elfů, pokračují trpaslíci k Jezernímu městu a nakonec k samotné Osamělé hoře, kde musí čelit největšímu nebezpečí v podobě Šmaka -  nejstrašlivější nestvůry, která prověří nejen jejich odvahu, ale i pevnost jejich přátelství a smysluplnost celé pouti.',2013,161,'1',NULL);

/*!40000 ALTER TABLE `wt_films` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wt_genres
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_genres`;

CREATE TABLE `wt_genres` (
  `zaner_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `datum_pridania` datetime NOT NULL,
  `nazov` tinytext NOT NULL,
  `schvaleny` enum('0','1') NOT NULL,
  PRIMARY KEY (`zaner_id`),
  KEY `autor_id` (`autor_id`),
  CONSTRAINT `wt_genres_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `wt_users` (`pouzivatel_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table wt_people
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_people`;

CREATE TABLE `wt_people` (
  `osobnost_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `autor_id` int(10) unsigned NOT NULL,
  `datum_pridania` datetime NOT NULL,
  `typ` tinyint(3) unsigned NOT NULL,
  `meno` tinytext NOT NULL,
  `narodnost` tinyint(3) unsigned DEFAULT NULL,
  `fotografia` tinytext,
  `popis` text NOT NULL,
  `schvaleny` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`osobnost_id`),
  KEY `autor_id` (`autor_id`),
  KEY `narodnost` (`narodnost`),
  KEY `typ` (`typ`),
  CONSTRAINT `wt_people_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `wt_users` (`pouzivatel_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `wt_people_ibfk_2` FOREIGN KEY (`typ`) REFERENCES `wt_professions` (`profesia_id`) ON UPDATE CASCADE,
  CONSTRAINT `wt_people_ibfk_3` FOREIGN KEY (`narodnost`) REFERENCES `wt_countries` (`krajina_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `wt_people` WRITE;
/*!40000 ALTER TABLE `wt_people` DISABLE KEYS */;

INSERT INTO `wt_people` (`osobnost_id`, `autor_id`, `datum_pridania`, `typ`, `meno`, `narodnost`, `fotografia`, `popis`, `schvaleny`)
VALUES
	(1,1,'2013-12-02 15:10:51',1,'Ben Stiller',NULL,'ben_small.jpg','Predstaviteľ loserov s imidžom nevysokého chlapíka s vysokými improvizačnými schopnosťami a čudnými vlasmi, sa stáva čoraz obľúbenejším. Herectvo má po rodičoch (Anne Mearaová & Jerry Stiller), ktorí sa ho a jeho sestru Amy od Hollywoodu márne snažili odhovoriť. Štúdium filmu v Los Angeles po pár mesiacoch uprednostnil pred filmovou praxou.','1'),
	(2,1,'2013-12-02 15:11:03',2,'Ben Stiller',NULL,'ben_small.jpg','Predstaviteľ loserov s imidžom nevysokého chlapíka s vysokými improvizačnými schopnosťami a čudnými vlasmi, sa stáva čoraz obľúbenejším. Herectvo má po rodičoch (Anne Mearaová & Jerry Stiller), ktorí sa ho a jeho sestru Amy od Hollywoodu márne snažili odhovoriť. Štúdium filmu v Los Angeles po pár mesiacoch uprednostnil pred filmovou praxou.','1'),
	(3,1,'2013-12-02 20:47:36',3,'Steve Conrad',NULL,NULL,'','1'),
	(4,1,'2013-12-02 20:48:04',4,'Stuart Dryburgh',NULL,NULL,'','1'),
	(5,1,'2013-12-02 20:48:30',5,'Theodore Shapiro',NULL,NULL,'','1'),
	(6,1,'2013-12-02 21:39:06',2,'Kristen Wiig',NULL,NULL,'','1'),
	(7,1,'2013-12-02 21:39:06',1,'Adam Scott',NULL,NULL,'','1');

/*!40000 ALTER TABLE `wt_people` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wt_professions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_professions`;

CREATE TABLE `wt_professions` (
  `profesia_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nazov` tinytext NOT NULL,
  PRIMARY KEY (`profesia_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `wt_professions` WRITE;
/*!40000 ALTER TABLE `wt_professions` DISABLE KEYS */;

INSERT INTO `wt_professions` (`profesia_id`, `nazov`)
VALUES
	(1,'Režisér'),
	(2,'Herec'),
	(3,'Scenár'),
	(4,'Kamera'),
	(5,'Hudba');

/*!40000 ALTER TABLE `wt_professions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table wt_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `wt_users`;

CREATE TABLE `wt_users` (
  `pouzivatel_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) unsigned NOT NULL,
  `meno` tinytext NOT NULL,
  `pohlavie` enum('0','1') DEFAULT NULL,
  `email` tinytext NOT NULL,
  `datum_registracie` datetime NOT NULL,
  PRIMARY KEY (`pouzivatel_id`),
  UNIQUE KEY `fb_id` (`fb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `wt_users` WRITE;
/*!40000 ALTER TABLE `wt_users` DISABLE KEYS */;

INSERT INTO `wt_users` (`pouzivatel_id`, `fb_id`, `meno`, `pohlavie`, `email`, `datum_registracie`)
VALUES
	(1,1,'Peter',NULL,'trubacik@gmail.com','2013-12-01 09:25:31');

/*!40000 ALTER TABLE `wt_users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
